// ******************************************************************************************
// Mod Name: Topic_Gems_Mod
// Mod Id: Topic_Gems_Mod_ModMike
// Mod Version: 1.0.0
// Mod File: main.js
// ******************************************************************************************
// Author: ModMike
// Last modified: 2/23/2016 5:00 AM
// ******************************************************************************************
// Notes: This file is defined in package.json and loaded as the first file from GDT
// ******************************************************************************************

// Setup a global mod object
var Topic_Gems_Mod_ModMike   = { modPath: '', data: {} };

(function(){
	// Acquire relative path to the mod
	Topic_Gems_Mod_ModMike.modPath = GDT.getRelativePath();

	// Callback executed after succesful load
	var ready = function () {
	};

// Callack executed if error(s) occured during load
	var error = function () {
	};

	// Load relevant files
	GDT.loadJs(['main/code_before.js', 'main/code.js', 'main/code_after.js'], ready, error);

})();
