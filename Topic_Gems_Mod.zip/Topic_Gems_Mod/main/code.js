// ******************************************************************************************
// Mod Name: Topic_Gems_Mod
// Mod Id: Topic_Gems_Mod_ModMike
// Mod Version: 1.0.0
// Mod File: code.js
// ******************************************************************************************
// Author: ModMike
// Last modified: 2/23/2016 5:00 AM
// ******************************************************************************************
// Notes: This file is loaded from main.js
// ******************************************************************************************

// Create the main mod object (our package)
var Topic_Gems_Mod = {};

(function(){

// ******************************************************************************************
// Topics
// ******************************************************************************************

GDT.addTopics([
{ 
	id: "18d8f657-17c1-4329-8af9-55fa020eaf9f",
	name: "Samurai",
	genreWeightings: [  1, 0.8, 0.9, 0.8, 0.6, 0.6 ],
	audienceWeightings: [  0.8, 0.9, 1 ]
	 }
,{ 
	id: "03eaaf92-85bd-410a-9453-2919382658a1",
	name: "Robots",
	genreWeightings: [  1, 0.8, 0.8, 1, 0.6, 0.9 ],
	audienceWeightings: [  0.9, 1, 0.8 ]
	 }
,{ 
	id: "dc88c8a8-a1b4-4bcb-b19d-d68f1ebd8026",
	name: "Mafia",
	genreWeightings: [  1, 1, 0.8, 0.6, 0.9, 0.6 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "6946d16a-f35d-43f9-ba6a-9c532c981349",
	name: "Mechanic",
	genreWeightings: [  0.8, 0.6, 0.6, 1, 0.9, 1 ],
	audienceWeightings: [  0.9, 1, 0.8 ]
	 }
,{ 
	id: "e377705b-6d7d-4981-b0d7-d090aee35bc4",
	name: "Beach",
	genreWeightings: [  1, 0.9, 0.8, 0.8, 0.6, 1 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "b116aff9-15e2-407c-9859-6d613189df09",
	name: "Religious",
	genreWeightings: [  0.6, 0.9, 0.8, 0.8, 0.6, 1 ],
	audienceWeightings: [  1, 0.9, 0.8 ]
	 }
,{ 
	id: "22934aa0-afb2-4d91-8892-05e58ab4b411",
	name: "Cultural",
	genreWeightings: [  0.9, 0.9, 0.7, 1, 0.6, 0.9 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "e0b7f9ce-2ff4-4972-82eb-cf866c9fd742",
	name: "Warlords",
	genreWeightings: [  1, 0.9, 1, 0.8, 1, 0.7 ],
	audienceWeightings: [  0.6, 0.9, 1 ]
	 }
,{ 
	id: "5cb36865-0a9b-44cc-bc80-c95c873d4fd1",
	name: "Deathmatch",
	genreWeightings: [  1, 0.7, 0.8, 1, 1, 0.6 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "82942e85-4198-4157-9373-789ab4234c64",
	name: "Otome",
	genreWeightings: [  0.9, 0.6, 0.9, 1, 0.6, 1 ],
	audienceWeightings: [  0.8, 0.9, 1 ]
	 }
,{ 
	id: "7a4c552e-2ffd-40b9-bfe9-d81e268f51b1",
	name: "Underwater",
	genreWeightings: [  0.9, 0.9, 0.9, 0.9, 0.6, 0.9 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "792452f0-8cd5-4b8f-9d5d-4bf2791ee4ec",
	name: "Console War",
	genreWeightings: [  0.9, 1, 0.9, 0.8, 1, 0.6 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "89a7138e-db21-4154-b2a1-3368a4534e03",
	name: "Housework",
	genreWeightings: [  0.9, 0.6, 0.6, 1, 0.7, 1 ],
	audienceWeightings: [  1, 1, 0.6 ]
	 }
,{ 
	id: "6d93d79c-9c7a-4799-bcea-f1ef9f4ff93b",
	name: "Ecchi",
	genreWeightings: [  1, 0.9, 0.9, 0.9, 0.8, 0.9 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "14af006a-557a-483b-9739-834798d19801",
	name: "Designer",
	genreWeightings: [  0.7, 0.6, 0.7, 1, 1, 0.9 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "fcb9e70b-ad4f-454a-8205-eda0e57b7bb8",
	name: "Knights",
	genreWeightings: [  1, 1, 1, 0.6, 0.9, 0.6 ],
	audienceWeightings: [  1, 1, 1 ]
	 }
,{ 
	id: "0de808fe-383c-4dbe-b4c1-86483468485d",
	name: "Survival Horror",
	genreWeightings: [  0.9, 0.8, 0.7, 1, 0.6, 0.8 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "caa803c7-4bb5-4c3d-9917-371bf50873f9",
	name: "Chess",
	genreWeightings: [  0.6, 0.6, 0.6, 1, 1, 1 ],
	audienceWeightings: [  0.8, 0.9, 0.9 ]
	 }
,{ 
	id: "ffaa1f0e-deaf-4dec-b0dc-5ae9f6703b18",
	name: "Fate",
	genreWeightings: [  1, 1, 1, 0.6, 0.6, 0.9 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "52dd8496-5bcf-4624-9f18-6c843eedbe4f",
	name: "Escape",
	genreWeightings: [  1, 0.9, 0.7, 1, 0.9, 0.6 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "9324de4c-c42b-4589-a409-5e2df178e335",
	name: "Crafting",
	genreWeightings: [  0.6, 0.7, 0.7, 1, 0.8, 1 ],
	audienceWeightings: [  1, 1, 1 ]
	 }
,{ 
	id: "97272af6-6210-49f6-9490-91749e7b32d0",
	name: "Psycology",
	genreWeightings: [  0.6, 1, 0.9, 0.8, 0.9, 0.9 ],
	audienceWeightings: [  0.8, 0.9, 1 ]
	 }
,{ 
	id: "2e747b59-44d9-4d0c-8278-316530f5ef56",
	name: "Education",
	genreWeightings: [  0.9, 1, 0.6, 1, 1, 1 ],
	audienceWeightings: [  1, 1, 1 ]
	 }
,{ 
	id: "9530ed33-9784-4eae-ba0e-f388390fcc1f",
	name: "Orcs",
	genreWeightings: [  1, 1, 1, 0.6, 0.6, 0.6 ],
	audienceWeightings: [  0.6, 0.9, 1 ]
	 }
,{ 
	id: "64d87997-5416-48eb-801d-4134333a889f",
	name: "Shoujo",
	genreWeightings: [  0.6, 0.9, 0.8, 0.9, 0.6, 1 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "c00a812e-c6dc-4366-833d-466ac311dec5",
	name: "Shonen",
	genreWeightings: [  0.8, 1, 0.9, 0.8, 0.8, 1 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "e5b28475-8998-45c3-aadb-357360a49fc9",
	name: "Hentai",
	genreWeightings: [  1, 0.8, 0.8, 0.9, 0.6, 0.9 ],
	audienceWeightings: [  0.6, 0.7, 1 ]
	 }
,{ 
	id: "d4f4cb91-e873-4696-b63d-dcc917eeb1f2",
	name: "Sniper",
	genreWeightings: [  1, 0.9, 0.6, 0.8, 1, 0.7 ],
	audienceWeightings: [  0.6, 0.9, 1 ]
	 }
,{ 
	id: "2a2a25e6-f0bf-48b1-96a8-d6e6d4edd9c5",
	name: "Zombie Apocalypse",
	genreWeightings: [  1, 0.9, 0.8, 0.6, 0.7, 0.7 ],
	audienceWeightings: [  0.7, 0.8, 1 ]
	 }
,{ 
	id: "bc271cad-8783-4069-8f4e-8c04f19d2723",
	name: "Anime",
	genreWeightings: [  0.8, 0.9, 0.9, 1, 0.8, 1 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "44b6b447-15f1-427a-910a-29d9e58368d6",
	name: "Photography",
	genreWeightings: [  1, 0.9, 0.6, 1, 0.6, 1 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "dd4137c7-d4ef-4fd0-a0d2-4a0295d84e97",
	name: "Aerial Warfare",
	genreWeightings: [  1, 0.8, 0.6, 1, 1, 0.7 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }

]);


})();
